package com.example.android.notepad;

import android.app.Activity;
import android.app.ListActivity;
import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleAdapter;
import android.widget.SimpleCursorAdapter;

public class NoteSearch extends Activity implements
        SearchView.OnQueryTextListener {

    private static final String[] PROJECTION = new String[] {

            NotePad.Notes._ID, // 0

            NotePad.Notes.COLUMN_NAME_TITLE, // 1

            //扩展 显示时间 颜色

            NotePad.Notes.COLUMN_NAME_MODIFICATION_DATE // 2

            //NotePad.Notes.COLUMN_NAME_BACK_COLOR

    };

    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.note_search);

        Intent intent = getIntent();

        if (intent.getData()
                == null) {

            intent.setData(NotePad.Notes.CONTENT_URI);

        }

        SearchView searchview =
                (SearchView)findViewById(R.id.search_view);

        //为查询文本框注册监听器

        searchview.setOnQueryTextListener(NoteSearch.this);

    }

    @Override

    public boolean onQueryTextSubmit(String query) {

        return false;

    }

    @Override

    public boolean onQueryTextChange(String newText) {

        String selection = NotePad.Notes.COLUMN_NAME_TITLE + " Like ? ";

        String[] selectionArgs = { "%"+newText+"%" };

        Cursor cursor = managedQuery(
                getIntent().getData(),
                PROJECTION,
                selection,
                selectionArgs,
                NotePad.Notes.DEFAULT_SORT_ORDER
        );

        String[] dataColumns = {
                NotePad.Notes.COLUMN_NAME_TITLE
                ,  NotePad.Notes.COLUMN_NAME_MODIFICATION_DATE };

        int[]
                viewIDs = { android.R.id.text1
                , R.id.list_view };

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.noteslist_item, cursor, dataColumns, viewIDs);
//        SimpleAdapter simpleAdapter =new SimpleAdapter(this,listItems,R.layout.simple_item,
//                new String[]{"Animalname","Animalhead"},new int[]{R.id.name,R.id.head});
        //setListAdapter(adapter);
        ListView list=(ListView)findViewById(R.id.list_view);
       list.setAdapter(adapter);
        System.out.printf("jieshu\n");
        return true;

    }

    //@Override

    protected void onListItemClick(ListView l, View v, int position, long
            id) {

        Uri uri = ContentUris.withAppendedId(getIntent().getData(),
                id);

        String action = getIntent().getAction();

        if (Intent.ACTION_PICK.equals(action)
                || Intent.ACTION_GET_CONTENT.equals(action)) {

            setResult(RESULT_OK, new Intent().setData(uri));

        } else {

            startActivity(new Intent(Intent.ACTION_EDIT, uri));

        }

    }

}
